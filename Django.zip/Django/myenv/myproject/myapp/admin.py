from django.contrib import admin
from .models import hardware
# Register your models here.

admin.site.register(hardware) 