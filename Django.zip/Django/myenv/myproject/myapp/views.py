from django.shortcuts import render,redirect
from myapp.models import *
import datetime
from myapp import models
# Create your views here.
def index(request):
    request.method="post"
    info=hardware.objects.all()
    return render(request,'index.html',{'info':info})

def add(request):
    if request.method=="POST":
        Producatname=request.POST.get('ProductName')
        brand=request.POST.get('Brand')
        color=request.POST.get('color')
        description=request.POST.get('Description')
        date=datetime.date.today()
        price=request.POST.get('Price')
        qty=request.POST.get('Qty')
        image=request.FILES['image']

        print(image)
        hardware.objects.create(
            ProductName=Producatname,
            Brand=brand,
            Color=color,
            Description=description,
            Date=date,
            Price=price,
            Qty=qty,
            Image=image
           )
        return redirect('home')
    return render(request,'index.html')

def update(request,id):
    if request.method=="POST":
        Producatname=request.POST.get('ProductName')
        brand=request.POST.get('Brand')
        color=request.POST.get('color')
        description=request.POST.get('Description')
        date=datetime.date.today()
        price=request.POST.get('Price')
        qty=request.POST.get('Qty')
        image=request.FILES['image']
        
        info=hardware(
            id=id,
            ProductName=Producatname,
            Brand=brand,
            Color=color,
            Description=description,
            Date=date,
            Price=price,
            Qty=qty,
            Image=image
        )
        info.save()
        return redirect('home')
    return render(request,'index.html')

def delete(request,id):
    info=hardware.objects.filter(id=id)
    info.delete()
    return redirect('home')
    
   
        