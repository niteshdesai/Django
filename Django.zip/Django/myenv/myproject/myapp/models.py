from django.db import models

# Create your models here.
class hardware(models.Model):
    ProductName=models.CharField(max_length=100)
    Brand=models.CharField(max_length=50)
    Color=models.CharField(max_length=40)
    Description=models.TextField(null=True)
    Date=models.DateField()
    Price=models.DecimalField(decimal_places=2,max_digits=10)
    Qty=models.IntegerField(default=1)
    Image=models.ImageField(null=True,blank=True,upload_to='media/')
    
    def __str__(self):
        return self.ProductName